
#include "MyCanvas.h"
#include <iostream>

bool MyCanvas::reDraw = false;
float MyCanvas::myRadius=0;
MyCanvas::MyCanvas()
{
}

MyCanvas::~MyCanvas()
{
}

void MyCanvas::display()
{
    // Clear the canvas
    clear();
    // -------------------------------------------------------------------------------------------
    // Draw a gray point in the middle of the canvas
	for (int x = 10; x < 400; x += 20)
		for (int y = 10; y < 400 ; y += 20)
			if (!reDraw)
				drawPoint(x, y, 127, 127, 127);
			else
			{
				float radDiffLow = (myRadius - 20)*(myRadius - 20);
				float radDiffHigh = (myRadius + 20)*(myRadius + 20);
				float distCircles = (x - leftClickPointStart.x)*(x - leftClickPointStart.x) + (y - leftClickPointStart.y)*(y - leftClickPointStart.y);
				if (radDiffLow <= distCircles && radDiffHigh >= distCircles)
					drawPoint(x, y, 0, 0, 127);
				else
					drawPoint(x, y, 127, 127, 127);
			}
    // Draw a red circle on the canvas
	if (reDraw)
	{
		drawCircle(leftClickPointStart.x, leftClickPointStart.y, myRadius, 0, 0, 127);
		drawCircle(leftClickPointStart.x, leftClickPointStart.y, myRadius+20, 127, 0, 0);
		drawCircle(leftClickPointStart.x, leftClickPointStart.y, myRadius-20, 127, 0, 0);
	}
    // -------------------------------------------------------------------------------------------
    // Make changes appear on screen
    swapBuffers();
}

void setLeftClickPointStart(int x, int y)
{
	//leftClickPoi = x;

}

void MyCanvas::onMouseButton(int button, int state, int x, int y)
{
	reDraw = false;
	display();
    // Process mouse button events.
    switch (button) {
		//std::cout << "Canvas::MouseEvent: "<<std::endl;
	case GLUT_LEFT_BUTTON:
		//leftClickPointStart.x = x;
		//leftClickPointStart.y = y;
		if (state == 0)
		{
			//std::cout << "Canvas::onMouseButton: " << state << ", " << x << ", " << y << std::endl;
			leftClickPointStart.x = x;
			leftClickPointStart.y = y;
			//std::cout << "Canvas::onMouseButton: " << state << ", " << leftClickPointStart.x << ", " << leftClickPointStart.y << std::endl;
		}
		else if (state == 1)
		{
			reDraw = true;
			leftClickPointEnd.x = x;
			leftClickPointEnd.y = y;
			//std::cout << "Canvas::onMouseButton: " << state << ", " << x << ", " << y << std::endl;
			//std::cout << "Canvas::onMouseButton: " << state << ", " << leftClickPointEnd.x << ", " << leftClickPointEnd.y << std::endl;
			myRadius = sqrt(float((leftClickPointStart.x - leftClickPointEnd.x)*(leftClickPointStart.x - leftClickPointEnd.x)) + float((leftClickPointStart.y - leftClickPointEnd.y)*(leftClickPointStart.y - leftClickPointEnd.y)));
			if (myRadius > leftClickPointStart.x)
				myRadius = leftClickPointStart.x;
			if (myRadius > leftClickPointStart.y)
				myRadius = leftClickPointStart.y;
			if (myRadius > 400 - leftClickPointStart.x)
				myRadius = 400 - leftClickPointStart.x;
			if (myRadius > 400 - leftClickPointStart.y)
				myRadius = 400 - leftClickPointStart.y;
			myRadius -= 25;
			//drawCircle(x1, y1, 40, 127, 0, 0
			//std::cout << "Canvas::onMouseButton:radius " << state << ", " << myRadius << ", " << leftClickPointStart.x << ", " << leftClickPointStart.y << ", " << leftClickPointEnd.x << ", " << leftClickPointEnd.y<< std::endl;
			display();
		}
			

        break;
    default:
		std::cout << "Canvas::onMouseButton: " << state << ", " << x << ", " << y << std::endl;
        break;
    }
    refresh();
}

void MyCanvas::onKeyboard(unsigned char key, int x, int y)
{
    // Process keyboard events.
    std::cout << "Canvas::onKeyboard: '" << key << "', " << x << ", " << y << std::endl;
    switch (key) {
    case 27: // ESC
        exit(0);
        break;
    default:
        break;
    }
    refresh();
}
