#ifndef MyCanvas_h
#define MyCanvas_h

#include "Canvas.h"

struct MyPoint {
	float x;
	float y;
};

class MyCanvas : public Canvas
{
	struct MyPoint leftClickPointStart;
	struct MyPoint leftClickPointEnd;
	static bool reDraw;
	static float myRadius;
public:
    MyCanvas();
    virtual ~MyCanvas();
    void display() override;
    void onKeyboard(unsigned char key, int x, int y) override;
    void onMouseButton(int button, int state, int x, int y) override;
	void setLeftClickPointStart(int x, int y);
	void setLeftClickPointEnd(int x, int y);
};

#endif // MyCanvas_h
